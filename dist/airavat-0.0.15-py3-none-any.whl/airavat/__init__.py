# __init__.py

# Version of the airavat package
__version__ = "0.0.13"